#include "TeslaTherm_v2.h"

// пин термистора, add_resist резистора, betta_coeff термистора, base_temp термистора, term_resist термистора, разрешение АЦП
float getTempFloat(uint8_t pin, int calibration, uint32_t add_resist, uint16_t betta_coeff, uint8_t base_temp, uint32_t term_resist, uint8_t resolution) {
    
    //Стоковый вариант гайвера

    float analog = analogRead(pin);
    float baseDiv = add_resist / term_resist;
    analog = baseDiv / ((float)((1 << resolution) - 1) / analog - 1.0f);
    analog = (log(analog) / betta_coeff) + 1.0f / (base_temp + 273.15f);
    return (1.0f / analog - 273.15f);
    

    /*

    // Читаем 1.1V опорное напряжение по отношению к Vcc
    ADMUX = _BV(REFS0) | _BV(MUX3) | _BV(MUX2) | _BV(MUX1);
    delay(2);             // Ждем немного для стабилизации напряжения
    ADCSRA |= _BV(ADSC);  // Запустим конвертацию
    while (bit_is_set(ADCSRA, ADSC))
        ;                   // Ждем окончания конвертации
    uint8_t low = ADCL;   // Берем младший байт результата
    uint8_t high = ADCH;  // Берем старший байт результата

    // Комбинируем два байта и преобразуем результат в Vcc
    long VIN = (high << 8) | low;
    VIN = 1125300L / VIN;  // Преобразовываем в милливольты

    float vcc = VIN / 1000.;

    float analog_input = analogRead(pin);
    float therm_mv = analog_input * vcc / 1024.;  //фактическое кол-во милливольт с датчика
    //float therm_norm = therm_mv * 4.995 / vcc;

    float temp = 1.0 / (log(therm_mv / (2.4975)) / betta_coeff + 1.0 / 298.0) - 273.0;

    return temp + (calibration);

    */


}

int getTemp(uint8_t pin, int calibration, uint32_t add_resist, uint16_t betta_coeff, uint8_t base_temp, uint32_t term_resist, uint8_t resolution) {
    int temperature = getTempFloat(pin, calibration, add_resist, betta_coeff, base_temp, term_resist, resolution);
    return temperature;
}