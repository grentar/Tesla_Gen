#ifndef _TeslaTherm_h_v2
#define _TeslaTherm_h_v2
#include <Arduino.h>

//! @param pin - пин Ардуино, к которому подключен термистор
//! @param calibration - дельта, на которую показания не соответствуют реальной температуре
//! @param add_resist - сопротивление резистора, установленного в делителе напряжения
//! @param betta_coeff - бетта-коэффициент термистора
//! @param base_temp - базовая температура термистора
//! @param term_resist - сопротивление термистора
//! @param resolution - разрешение АЦП
float getTempFloat(uint8_t pin, int calibration = -2, uint32_t add_resist = 10000, uint16_t betta_coeff = 3950, uint8_t base_temp = 20, uint32_t term_resist = 10000, uint8_t resolution = 10);
int getTemp(uint8_t pin, int calibration = -2, uint32_t add_resist = 10000, uint16_t betta_coeff = 3950, uint8_t base_temp = 20, uint32_t term_resist = 10000, uint8_t resolution = 10);

#endif